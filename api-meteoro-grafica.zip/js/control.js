let esConmutadorOn=false; // conmutador de mostrar gráfica

const obtenerDatos= evento=> {
    // evento.preventDefault(); // ¡no usar para no desactivar eventos necesarios!
    // console.log(evento);
    let zona=$("#lugar").val().trim();
    while (zona.includes("  "))
        zona=zona.replace("  "," ");
    if (esConmutadorOn)
        dibujarGrafica(zona);
    else
        presentarInforme(zona);
    return;
};

const detectarTecla= evento=> {
    // console.log(evento);
    if (evento.keyCode==13)
        obtenerDatos();
    else
        borrarDatos();
    return;
}

const conmutarSalida= evento=> {
    // console.log(evento);
    esConmutadorOn=!esConmutadorOn;
    $("#imgconmutador").attr("src", esConmutadorOn ? "img/conmutador-on.png" : "img/conmutador-off.png");
    borrarDatos();
    obtenerDatos();
    return;
}

const borrarDatos= ()=> {
    $("#salida").fadeOut("fast", ()=> {
        $("#informe").html("");
        $("#icono").html("");
        $("#salida").fadeIn("fast");
    });
    $("#grafica").fadeOut("fast", ()=> {
        $("#grafica").html("");
    });
    return;
}

const presentarInforme= zona=> {
    $.ajax({
        url: "https://api.openweathermap.org/data/2.5/weather?lang=es&units=metric&q="+zona+"&appid=4e41eebb284c9c59812dcde2ed3fdd7e",
        dataType: "json",
        success: infor=> {
            // console.log(infor);
            $("#lugar").val(infor.name);
            let resultado=
                    "<br/><span class='etiqueta1' >población:</span><strong>"+
                        infor.name+
                    "</strong>"+
                    "<br/><span class='etiqueta1' >código ISO país:</span><strong>"+
                        infor.sys.country.toLowerCase()+
                    "</strong>"+
                    "<br/><span class='etiqueta1' >longitud:</span><strong>"+
                        infor.coord.lon+
                    "</strong>&deg;"+
                    "<br/><span class='etiqueta1' >latitud:</span><strong>"+
                        infor.coord.lat+
                    "</strong>&deg;"+
                    "<br/><span class='etiqueta1' >temperatura actual:</span><strong>"+
                        infor.main.temp+
                    "</strong>&deg;C"+
                    "<br/><span class='etiqueta1' >temperatura mínima:</span><strong>"+
                        infor.main.temp_min+
                    "</strong>&deg;C"+
                    "<br/><span class='etiqueta1' >temperatura máxima:</span><strong>"+
                        infor.main.temp_max+
                    "</strong>&deg;C"+
                    "<br/><span class='etiqueta1' >presión atmosférica:</span><strong>"+
                        infor.main.pressure+
                    "</strong> hPa"+
                    "<br/><span class='etiqueta1' >humedad relativa:</span><strong>"+
                        infor.main.humidity+
                    "</strong>%"+
                    "<br/><span class='etiqueta1' >velocidad del viento:</span><strong>"+
                        Math.floor(infor.wind.speed*3.6)+
                    "</strong> km/h"+
                    "<br/><span class='etiqueta1' >resumen:</span><strong>"+
                        infor.weather[0].description+
                    "</strong>";

            //console.log(iconosMeteo[infor.weather[0].icon]+".png");
            let rutaIcono="http://openweathermap.org/img/w/"+infor.weather[0].icon+".png";
            let contenidoIcono=
                    "<br/><br/><br/><br/><figure><img  src='"+rutaIcono+"' width=100 class='figure-img img-fluid rounded' alt='"+
                        infor.weather[0].description+
                    "' /><figcaption class='figure-caption text-center' ><i>"+
                        infor.weather[0].description+
                    "</i></figcaption></figure>";

            $("#salida").fadeOut("fast", ()=> {
                $("#informe").html(resultado);
                $("#icono").html(contenidoIcono);
                $("#salida").fadeIn("fast");
                return;
            });
        },
        error: informarDesconocido
    });
    return;
};

const informarDesconocido= ()=> {
    //console.log("Error obteniendo datos.");
    $("#grafica").fadeOut("fast", ()=> {
        $("#grafica").html("");
        return;
    });
    $("#salida").fadeOut("fast", ()=> {
        $("#informe").html("<br/><span class='etiqueta1' ></span><strong><em>Población no encontrada</em></strong>");
        $("#icono").html("");
        $("#salida").fadeIn("fast");
    });
    return;
}

const dibujarGrafica= zona=> {
    $.ajax({
        url: "https://api.openweathermap.org/data/2.5/forecast?lang=es&units=metric&q="+zona+"&appid=4e41eebb284c9c59812dcde2ed3fdd7e",
        dataType: "json",
        success: infor=> {
            // console.log(infor);
            $("#lugar").val(infor.city.name);
            let resultado="<img id=fondograf alt='' src='img/fondo-grafica.png' />";
            let maxMuestras=infor.list.length;
            for (let num=0; num<maxMuestras; num++) {
                resultado+=
                        "<img alt='' title='fecha: "+
                        infor.list[num].dt_txt+
                        "\n temperatura: "+
                        infor.list[num].main.temp+
                        "&deg;C' "+
                        "src='img/simbolo-muestra.png' class='simbolo-muestra' style='left: "+
                        calcularX(num, maxMuestras)+
                        "px; top: "+
                        calcularY(infor.list[num].main.temp)+
                        "px;' />";
            }
            $("#grafica").fadeOut("fast", ()=> {
                $("#grafica").html(resultado).fadeIn("fast");
                return;
            });
        },
        error: informarDesconocido
    });
    return;
}

const calcularX= (num, total)=> {
    return 865/(total-1)*num+68;
}

const calcularY= temperatura=> {
    return 340-4.166*temperatura;
}

$("#btnobtener").on("click", obtenerDatos);
$("#lugar").on("keyup", detectarTecla);
$("#imgconmutador").on("click", conmutarSalida);
